/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 28 Jan 2020, 11:57:47                       ---
 * ----------------------------------------------------------------
 */
package com.hybris.cxtech.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast"})
public class GeneratedWeatherConstants
{
	public static final String EXTENSIONNAME = "weather";
	public static class TC
	{
		public static final String WEATHERCOMPONENT = "WeatherComponent".intern();
	}
	public static class Attributes
	{
		// no constants defined.
	}
	
	protected GeneratedWeatherConstants()
	{
		// private constructor
	}
	
	
}
