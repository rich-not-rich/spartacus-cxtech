/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 28 Jan 2020, 11:57:47                       ---
 * ----------------------------------------------------------------
 */
package com.hybris.cxtech.weather.jalo;

import de.hybris.platform.cms2.jalo.contents.components.SimpleCMSComponent;
import de.hybris.platform.directpersistence.annotation.SLDSafe;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type WeatherComponent.
 */
@SLDSafe
@SuppressWarnings({"unused","cast"})
public class WeatherComponent extends SimpleCMSComponent
{
	/** Qualifier of the <code>WeatherComponent.location</code> attribute **/
	public static final String LOCATION = "location";
	/** Qualifier of the <code>WeatherComponent.weather</code> attribute **/
	public static final String WEATHER = "weather";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(SimpleCMSComponent.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(LOCATION, AttributeMode.INITIAL);
		tmp.put(WEATHER, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>WeatherComponent.location</code> attribute.
	 * @return the location - Location to be used for the weather component
	 */
	public String getLocation(final SessionContext ctx)
	{
		return (String)getProperty( ctx, "location".intern());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>WeatherComponent.location</code> attribute.
	 * @return the location - Location to be used for the weather component
	 */
	public String getLocation()
	{
		return getLocation( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>WeatherComponent.location</code> attribute. 
	 * @param value the location - Location to be used for the weather component
	 */
	public void setLocation(final SessionContext ctx, final String value)
	{
		setProperty(ctx, "location".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>WeatherComponent.location</code> attribute. 
	 * @param value the location - Location to be used for the weather component
	 */
	public void setLocation(final String value)
	{
		setLocation( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>WeatherComponent.weather</code> attribute.
	 * @return the weather - Weather data
	 */
	public Map<String,Double> getAllWeather(final SessionContext ctx)
	{
		Map<String,Double> map = (Map<String,Double>)getProperty( ctx, "weather".intern());
		return map != null ? map : Collections.EMPTY_MAP;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>WeatherComponent.weather</code> attribute.
	 * @return the weather - Weather data
	 */
	public Map<String,Double> getAllWeather()
	{
		return getAllWeather( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>WeatherComponent.weather</code> attribute. 
	 * @param value the weather - Weather data
	 */
	public void setAllWeather(final SessionContext ctx, final Map<String,Double> value)
	{
		setProperty(ctx, "weather".intern(),value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>WeatherComponent.weather</code> attribute. 
	 * @param value the weather - Weather data
	 */
	public void setAllWeather(final Map<String,Double> value)
	{
		setAllWeather( getSession().getSessionContext(), value );
	}
	
}
